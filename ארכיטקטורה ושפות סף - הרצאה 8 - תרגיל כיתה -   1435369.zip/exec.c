#include "common.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

void run(int n, char * const name) {

    // IMPLEMENT
}

void before(int n) {
    // IMPLEMENT
}

void after(int n) {

    // IMPLEMENT
}
