#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <wait.h>
#include <string.h>

void run(int n, char * const name) {

    // IMPLEMENT
}

void before(int n) {
    // IMPLEMENT
}

void after(int n) {

    // IMPLEMENT
}
